<?php
include("database.php");
// On inclue le fichier de configuration et de connexion à la base de données

// On récupère dans $_GET le login soumis par l'utilisateur

// On prépare la requete qui recherche la présence de l'email dans la table player

}
?>
