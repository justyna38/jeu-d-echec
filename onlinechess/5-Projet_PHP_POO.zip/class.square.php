<?php

// Cette classe représente les case du plateau
class OnlineChess_Square {

	function __construct($x, $y) {

	}
	
	// Cette methode est un getter qui renvoie la propriete $this->piece
	public function hasPiece() :bool  {

	}
}

?>