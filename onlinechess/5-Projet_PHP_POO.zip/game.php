<?php
require_once "class.chess.php";

session_start();

// On initialise le tableau $_SESSION

// On instancie la classe OnlineChess

// On recupere le login du joueur dont c'est le tour par la methode $chess->getPlayer


// On recupere le dossier des images des pièces par la methode $chess->setImageDir

?>

<html lang="fr">
  <head>
  <!-- NB : ne refraichier la page que si le joueur attend son tour-->
  	<meta http-equiv="Refresh" content="5;url=game.php">

    <title>Online Chess \_|_/</title>
    <!-- CUSTOM STYLE  -->
    <link href="css/style.css" rel="stylesheet" />

    <script type="text/javascript"	src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.3/jquery.min.js"></script>
	<!-- script type="text/javascript"	src="js/game.js"></script -->
  </head>

  <body>
    <h1>Online Chess</h1>
 
<?php
// On affiche un message aux utilisateurs si nécezzaire
echo '<p style="text-align: center;">' . $chess->message(true) . '</p>';

// Affiche le plateau au moyen de la méthode board
$chess->board();

// Affiche le formulaire de soumission du mouvement au moyen de la methode form
$chess->form();
?>
</body>
</html>
